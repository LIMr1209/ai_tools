# coding: utf-8
from flask_celery import Celery

celery = Celery()  # celery 对象
