from flask import current_app

import app.lib.stylegan_tensorflow.dnnlib.tflib as tflib
from app.helpers.common import img_to_base64
from app.lib.stylegan_tensorflow.dnnlib import EasyDict
import numpy as np
from PIL import Image
import pickle

network_path = current_app.config['STYLEGAN_TE_PATH']
truncation_psi = 0.5

def load_model():
    stream = open(network_path, 'rb')
    tflib.init_tf()
    with stream:
        G, D, Gs = pickle.load(stream, encoding='latin1')
    noise_vars = [var for name, var in Gs.components.synthesis.vars.items() if name.startswith('noise')]

    Gs_kwargs = EasyDict()
    Gs_kwargs.output_transform = dict(func=tflib.convert_images_to_uint8, nchw_to_nhwc=True)
    Gs_kwargs.randomize_noise = False
    Gs_kwargs.truncation_psi = truncation_psi
    return Gs,Gs_kwargs,noise_vars


def get_sample(seed):
    Gs,Gs_kwargs,noise_vars = load_model()
    rnd = np.random.RandomState(seed)
    z = rnd.randn(1, *Gs.input_shape[1:]) # [minibatch, component]
    tflib.set_vars({var: rnd.randn(*var.shape.as_list()) for var in noise_vars}) # [height, width]
    images = Gs.run(z, None, **Gs_kwargs) # [minibatch, height, width, channel]
    img = Image.fromarray(images[0], 'RGB')
    base64_str_data = img_to_base64(img)
    return base64_str_data, seed